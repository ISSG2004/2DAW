package com.example;

public class Ingeniero extends Persona {
    public void razonar() {
        System.out.println("El ingeniero esta razonando");
    }

    public void trabajarEnGrupo() {
        System.out.println("El ingeniero esta trabajando en grupo.");
    }
}
