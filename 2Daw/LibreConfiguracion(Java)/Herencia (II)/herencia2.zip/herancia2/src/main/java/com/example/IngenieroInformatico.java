package com.example;

public class IngenieroInformatico extends Ingeniero {
    public void crearPrograma() {
        System.out.println("El ingeniero informático ha creado un nuevo programa.");
    }
}
