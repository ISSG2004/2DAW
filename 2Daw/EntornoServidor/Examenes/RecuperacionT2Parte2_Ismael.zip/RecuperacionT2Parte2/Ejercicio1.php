<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        function sumarValoresArrayRec($array) {
            if (empty($array)) {//caso base
                return 0;//devolvemos 0 
            }//caso recursivo
            return $array[0] + sumarValoresArrayRec(array_slice($array, 1));//realizamos la llamada recursiva
        }

        $array = array(1,2,3,4,5);
        echo "Suma de todos los valores del array: " .sumarValoresArrayRec($array);
    ?>
</body>
</html>